@echo off
python -m PyInstaller input_visualiser_nc.py --onefile --noconsole --icon="%USERPROFILE%\Downloads\icons8-key-press-ios-17-outlined\icons8-key-press-50.ico"
pause